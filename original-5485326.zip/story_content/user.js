function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6mhW0ZSym5H":
        Script1();
        break;
  }
}

function Script1()
{
  lmsAPI.ConcedeControl();
}

