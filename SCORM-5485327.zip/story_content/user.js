function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6i5ZoK0nKkx":
        Script1();
        break;
  }
}

function Script1()
{
  lmsAPI.ConcedeControl();
}

